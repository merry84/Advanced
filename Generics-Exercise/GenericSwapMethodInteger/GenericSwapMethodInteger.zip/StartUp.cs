﻿namespace GenericSwapMethodInteger
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
             Box<int> box = new Box<int>();
            for (int i = 0; i < n; i++)
            {
                int number = int.Parse(Console.ReadLine());
                box.Add(number);
            }

            int[] command = Console.ReadLine()
                    .Split()
                    .Select(int.Parse)
                    .ToArray();
            int first = command[0];
            int second = command[1];
            box.Swap(first,second);
            Console.WriteLine(box);
        }
    }
}
